-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2025 at 06:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laliga_2024_2025`
--

-- --------------------------------------------------------

--
-- Table structure for table `goals`
--

CREATE TABLE `goals` (
  `goal_id` int(11) NOT NULL,
  `match_id` int(11) DEFAULT NULL,
  `player_id` int(11) DEFAULT NULL,
  `minute_scored` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `goals`
--

INSERT INTO `goals` (`goal_id`, `match_id`, `player_id`, `minute_scored`) VALUES
(1, 1, 1, 23),
(2, 1, 2, 65),
(3, 1, 3, 78),
(4, 2, 4, 54),
(5, 2, 5, 89),
(6, 3, 1, 15),
(7, 3, 2, 47),
(8, 3, 2, 75),
(9, 4, 7, 33),
(10, 4, 9, 41),
(11, 4, 9, 77),
(12, 5, 11, 22),
(13, 5, 12, 80),
(14, 5, 13, 55),
(15, 5, 14, 70),
(16, 6, 15, 10),
(17, 6, 15, 68),
(18, 6, 7, 73),
(19, 7, 10, 45),
(20, 8, 15, 60),
(21, 8, 16, 81),
(22, 8, 16, 88);

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `match_id` int(11) NOT NULL,
  `home_team_id` int(11) DEFAULT NULL,
  `away_team_id` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `home_score` int(11) DEFAULT NULL,
  `away_score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`match_id`, `home_team_id`, `away_team_id`, `match_date`, `home_score`, `away_score`) VALUES
(1, 1, 2, '2024-09-01', 2, 1),
(2, 2, 3, '2024-09-08', 1, 1),
(3, 3, 1, '2024-09-15', 0, 3),
(4, 4, 5, '2024-09-22', 1, 2),
(5, 6, 7, '2024-09-29', 2, 2),
(6, 8, 4, '2024-10-06', 3, 1),
(7, 5, 6, '2024-10-13', 0, 0),
(8, 7, 8, '2024-10-20', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(20) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`player_id`, `name`, `position`, `nationality`, `team_id`) VALUES
(1, 'Jude Bellingham', 'Midfielder', 'England', 1),
(2, 'Vinícius Júnior', 'Forward', 'Brazil', 1),
(3, 'Robert Lewandowski', 'Forward', 'Poland', 2),
(4, 'Pedri', 'Midfielder', 'Spain', 2),
(5, 'Antoine Griezmann', 'Forward', 'France', 3),
(6, 'Jan Oblak', 'Goalkeeper', 'Slovenia', 3),
(7, 'Youssef En-Nesyri', 'Forward', 'Morocco', 4),
(8, 'Jesús Navas', 'Defender', 'Spain', 4),
(9, 'Iñaki Williams', 'Forward', 'Ghana', 5),
(10, 'Unai Simón', 'Goalkeeper', 'Spain', 5),
(11, 'José Gayà', 'Defender', 'Spain', 6),
(12, 'Hugo Duro', 'Forward', 'Spain', 6),
(13, 'Isco', 'Midfielder', 'Spain', 7),
(14, 'Borja Iglesias', 'Forward', 'Spain', 7),
(15, 'Mikel Oyarzabal', 'Forward', 'Spain', 8),
(16, 'Takefusa Kubo', 'Midfielder', 'Japan', 8);

-- --------------------------------------------------------

--
-- Table structure for table `stadiums`
--

CREATE TABLE `stadiums` (
  `stadium_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stadiums`
--

INSERT INTO `stadiums` (`stadium_id`, `name`, `city`, `capacity`) VALUES
(1, 'Santiago Bernabéu', 'Madrid', 81044),
(2, 'Camp Nou', 'Barcelona', 99354),
(3, 'Wanda Metropolitano', 'Madrid', 68456),
(4, 'Ramón Sánchez Pizjuán', 'Seville', 43883),
(5, 'San Mamés', 'Bilbao', 53289),
(6, 'Mestalla', 'Valencia', 55000),
(7, 'Benito Villamarín', 'Seville', 60720),
(8, 'Reale Arena', 'San Sebastián', 39000);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `stadium_id` int(11) DEFAULT NULL,
  `coach` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team_id`, `name`, `stadium_id`, `coach`) VALUES
(1, 'Real Madrid', 1, 'Carlo Ancelotti'),
(2, 'FC Barcelona', 2, 'Xavi Hernández'),
(3, 'Atlético Madrid', 3, 'Diego Simeone'),
(4, 'Sevilla FC', 4, 'Quique Sánchez Flores'),
(5, 'Athletic Bilbao', 5, 'Ernesto Valverde'),
(6, 'Valencia CF', 6, 'Rubén Baraja'),
(7, 'Real Betis', 7, 'Manuel Pellegrini'),
(8, 'Real Sociedad', 8, 'Imanol Alguacil');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `goals`
--
ALTER TABLE `goals`
  ADD PRIMARY KEY (`goal_id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `home_team_id` (`home_team_id`),
  ADD KEY `away_team_id` (`away_team_id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `stadiums`
--
ALTER TABLE `stadiums`
  ADD PRIMARY KEY (`stadium_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `stadium_id` (`stadium_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `goals`
--
ALTER TABLE `goals`
  MODIFY `goal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `stadiums`
--
ALTER TABLE `stadiums`
  MODIFY `stadium_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `team_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `goals`
--
ALTER TABLE `goals`
  ADD CONSTRAINT `goals_ibfk_1` FOREIGN KEY (`match_id`) REFERENCES `matches` (`match_id`),
  ADD CONSTRAINT `goals_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `players` (`player_id`);

--
-- Constraints for table `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`home_team_id`) REFERENCES `teams` (`team_id`),
  ADD CONSTRAINT `matches_ibfk_2` FOREIGN KEY (`away_team_id`) REFERENCES `teams` (`team_id`);

--
-- Constraints for table `players`
--
ALTER TABLE `players`
  ADD CONSTRAINT `players_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`);

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`stadium_id`) REFERENCES `stadiums` (`stadium_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
